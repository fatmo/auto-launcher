package mx.autolauncher

import android.content.Intent
import android.provider.Settings
import android.view.KeyEvent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.DirectionsCar
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Amber = Color(0xFFFFB020)

@Composable
fun MxCard(u: Dp, modifier: Modifier = Modifier, edge: Color = Mx.Line, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(u * 2.6f)
    Column(modifier.clip(shape).background(Mx.Panel).border(1.dp, edge, shape).padding(u * 1.6f),
        verticalArrangement = Arrangement.Center, content = content)
}

@Composable
fun Txt(s: String, u: Dp, k: Float, color: Color = Mx.Text, bold: Boolean = false, mono: Boolean = false) =
    Text(s, color = color, fontSize = (u.value * k).sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontFamily = if (mono) Mx.Tech else FontFamily.Default)

@Composable
fun CarCard(u: Dp, modifier: Modifier, onClick: () -> Unit) {
    val now by produceState(Date()) { while (true) { value = Date(); delay(5_000) } }
    MxCard(u, modifier.clickable(onClick = onClick), edge = Mx.Blue) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(u)) {
            Icon(Icons.Rounded.DirectionsCar, null, tint = Mx.Blue2, modifier = Modifier.size(u * 7))
            Column {
                Txt(Cfg.carName, u, 3.8f, bold = true)
                Txt(Cfg.carModel, u, 2.2f, Mx.Mute)
            }
        }
        Spacer(Modifier.height(u * 0.6f))
        Txt(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now), u, 8f, bold = true, mono = true)
        Txt(SimpleDateFormat("EEEE d 'de' MMMM", Locale.getDefault()).format(now), u, 2.4f, Mx.Mute)
    }
}

@Composable
fun SpeedCard(u: Dp, modifier: Modifier) = MxCard(u, modifier) {
    val spd = if (Obd.connected) (Obd.speed ?: Trip.speedKmh) else Trip.speedKmh
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(u)) {
        Txt(spd.toString(), u, 11f, Mx.Blue2, bold = true, mono = true)
        Txt("km/h", u, 2.8f, Mx.Mute)
    }
    if (Obd.connected) {
        Txt("${Obd.rpm ?: "–"} rpm · ${Obd.coolant ?: "–"}°C · ${Obd.volts?.let { "%.1f".format(it) } ?: "–"} V", u, 2.2f)
        val pct = Obd.fuelPct
        if (pct == null) Txt("Gasolina –", u, 2.2f, Mx.Mute)
        else {
            val liters = pct * Cfg.tankL / 100.0
            val kmL = if (Cfg.avgKmL > 0) Cfg.avgKmL else (Obd.tripKmL ?: 0.0)
            val range = if (kmL > 0) " · ~${"%.0f".format(liters * kmL)} km" else ""
            Txt(if (pct <= 15) "¡Reserva! ${"%.0f".format(liters)} L$range" else "Gasolina $pct% · ${"%.0f".format(liters)} L$range",
                u, 2.2f, if (pct <= 15) Amber else Mx.Mute, bold = pct <= 15)
        }
    } else Txt(if (Trip.lat == null) "Buscando GPS…" else "GPS · OBD: ${Obd.status}", u, 2f, Mx.Mute)
}

@Composable
fun WeatherCard(u: Dp, modifier: Modifier, wx: Wx?) = MxCard(u, modifier) {
    if (wx == null) {
        Txt("Clima", u, 2.8f, Mx.Mute)
        Txt(if (Trip.lat == null) "Esperando ubicación…" else "Cargando…", u, 2.4f, Mx.Mute)
    } else {
        Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(u)) {
            Txt("${wx.temp}°", u, 8f, bold = true, mono = true)
            Txt(wx.desc, u, 2.6f, Mx.Blue2)
        }
        Txt("Máx ${wx.max}°  ·  Mín ${wx.min}°", u, 2.4f)
        Txt("Lluvia ${wx.rain}%", u, 2.4f, if (wx.rain >= 50) Mx.Blue2 else Mx.Mute)
    }
}

@Composable
fun TripCard(u: Dp, modifier: Modifier, onClick: () -> Unit) {
    val left = Trip.oilRemaining()
    val warn = left <= 500
    MxCard(u, modifier.clickable(onClick = onClick), edge = if (warn) Amber else Mx.Line) {
        Txt("Hoy  ${"%.1f".format(Trip.dayKm)} km", u, 3.2f, bold = true)
        Txt("Mes  ${"%.0f".format(Trip.monthKm)} km", u, 2.6f, Mx.Mute)
        if (Obd.connected && Obd.lph != null) {
            val ahora = Obd.instKmL
            Txt(if (ahora != null) "Ahora ${"%.1f".format(ahora)} km/L" else "Ralentí ${"%.1f".format(Obd.lph)} L/h", u, 2.6f, Mx.Blue2, bold = true)
            Obd.tripKmL?.let { Txt("Viaje (OBD) ${"%.1f".format(it)} km/L", u, 2.2f, Mx.Mute) }
        }
        Spacer(Modifier.height(u * 0.6f))
        if (Cfg.fuelBase < 0) Txt("Rendimiento: registra un tanque", u, 2.2f, Mx.Mute)
        else {
            Txt(if (Cfg.lastKmL > 0) "${"%.1f".format(Cfg.lastKmL)} km/L  (prom ${"%.1f".format(Cfg.avgKmL)})" else "Rendimiento: falta otro tanque",
                u, 2.6f, Mx.Blue2, bold = true)
            Txt("Tanque actual: ${"%.0f".format(maxOf(0.0, Trip.totalKm - Cfg.fuelBase))} km", u, 2.2f, Mx.Mute)
        }
        Spacer(Modifier.height(u * 0.6f))
        Txt(
            if (left <= 0) "¡Cambio de aceite vencido!" else if (warn) "¡Aceite en ${"%.0f".format(left)} km!" else "Aceite: faltan ${"%.0f".format(left)} km",
            u, 2.4f, if (warn) Amber else Mx.Text, bold = warn
        )
    }
}

@Composable
fun PlayerCard(u: Dp, modifier: Modifier) {
    val ctx = LocalContext.current
    val np by produceState(NP(true)) { while (true) { value = readNP(ctx); delay(1000) } }
    val tc = np.c?.transportControls
    MxCard(u, modifier) {
        if (!np.ok) {
            Txt("Para ver la carátula activa el acceso a notificaciones", u, 2.2f, Mx.Mute)
            Spacer(Modifier.height(u))
            DockButton("Activar acceso", u, Modifier.fillMaxWidth()) {
                Actions.launch(ctx, Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }
        } else Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(u * 1.6f)) {
            val art = remember(np.art) { np.art?.asImageBitmap() }
            Box(Modifier.fillMaxHeight().aspectRatio(1f).clip(RoundedCornerShape(u * 1.6f)).background(Mx.Panel2),
                contentAlignment = Alignment.Center) {
                if (art != null) Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(Icons.Rounded.MusicNote, null, tint = Mx.Blue2, modifier = Modifier.size(u * 8))
            }
            Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Txt(np.title.ifEmpty { "Sin música" }, u, 3f, bold = true)
                    Txt(np.artist, u, 2.2f, Mx.Mute)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(u)) {
                    CtlBtn("⏮", u, Modifier.weight(1f)) { tc?.skipToPrevious() ?: Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
                    CtlBtn(if (np.playing) "⏸" else "▶", u, Modifier.weight(1f)) {
                        if (tc != null) { if (np.playing) tc.pause() else tc.play() }
                        else Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
                    }
                    CtlBtn("⏭", u, Modifier.weight(1f)) { tc?.skipToNext() ?: Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT) }
                }
            }
        }
    }
}

@Composable
private fun CtlBtn(s: String, u: Dp, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.heightIn(min = 44.dp).height(u * 7).clip(RoundedCornerShape(u * 1.6f)).background(Mx.Bg)
        .clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(s, color = Mx.Blue2, fontSize = (u.value * 3.2f).sp)
    }
}
