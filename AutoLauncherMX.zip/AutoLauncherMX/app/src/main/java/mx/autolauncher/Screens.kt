package mx.autolauncher

import android.graphics.drawable.GradientDrawable
import android.view.MotionEvent
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File

/** Mapa oscuro con el recorrido. El zoom se acerca en ciudad y se abre en carretera. */
@Composable
fun MapScreen(u: Dp, close: () -> Unit) {
    val ctx = LocalContext.current
    var follow by remember { mutableStateOf(true) }
    val mv = remember {
        Configuration.getInstance().apply {
            userAgentValue = ctx.packageName
            osmdroidBasePath = File(ctx.cacheDir, "osm")
            osmdroidTileCache = File(ctx.cacheDir, "osm/tiles")
        }
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            overlayManager.tilesOverlay.setColorFilter(TilesOverlay.INVERT_COLORS)
            controller.setZoom(16.0)
            setOnTouchListener { _, e -> if (e.action == MotionEvent.ACTION_DOWN) follow = false; false }
        }
    }
    val line = remember { Polyline().apply { outlinePaint.color = 0xFF2D7BFF.toInt(); outlinePaint.strokeWidth = 12f } }
    val me = remember {
        Marker(mv).apply {
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            icon = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF5AA0FF.toInt()); setSize(40, 40); setStroke(5, 0xFFFFFFFF.toInt()) }
        }
    }
    DisposableEffect(Unit) {
        mv.overlays.add(line); mv.overlays.add(me); mv.onResume()
        onDispose { mv.onPause(); mv.onDetach() }
    }
    val spd = if (Obd.connected) (Obd.speed ?: Trip.speedKmh) else Trip.speedKmh
    val zoom = when { spd < 20 -> 17.5; spd < 50 -> 16.5; spd < 80 -> 15.5; spd < 105 -> 14.5; else -> 14.0 }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { mv }, modifier = Modifier.fillMaxSize(), update = { m ->
            line.setPoints(Trip.track.map { GeoPoint(it.first, it.second) })
            val la = Trip.lat; val lo = Trip.lon
            if (la != null && lo != null) {
                me.position = GeoPoint(la, lo)
                if (follow) {
                    m.controller.animateTo(GeoPoint(la, lo))
                    if (kotlin.math.abs(m.zoomLevelDouble - zoom) > 0.4) m.controller.zoomTo(zoom, 700L)
                }
            }
            m.invalidate()
        })
        MxCard(u, Modifier.align(Alignment.TopStart).padding(u * 2)) {
            Txt("$spd km/h", u, 5f, Mx.Blue2, bold = true, mono = true)
            Txt("Hoy ${"%.1f".format(Trip.dayKm)} km", u, 2.4f, Mx.Mute)
        }
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(u * 2), horizontalArrangement = Arrangement.spacedBy(u * 1.5f)) {
            DockButton("Waze", u, Modifier.weight(1f)) { Actions.waze(ctx) }
            DockButton("Google Maps", u, Modifier.weight(1f)) { Actions.gmaps(ctx) }
            DockButton("Recentrar", u, Modifier.weight(1f)) { follow = true }
            DockButton("Nuevo viaje", u, Modifier.weight(1f)) { Trip.track.clear() }
            DockButton("◀ Inicio", u, Modifier.weight(1f), close)
        }
    }
}

/** YouTube dentro del launcher (versión web móvil). */
@Composable
fun YouTubeScreen(u: Dp, close: () -> Unit) {
    var web by remember { mutableStateOf<WebView?>(null) }
    DisposableEffect(Unit) { onDispose { web?.destroy() } }
    Column(Modifier.fillMaxSize().padding(u * 2), verticalArrangement = Arrangement.spacedBy(u * 1.5f)) {
        Row(horizontalArrangement = Arrangement.spacedBy(u * 1.5f)) {
            DockButton("◀ Inicio", u, Modifier.weight(1f), close)
            DockButton("Atrás", u, Modifier.weight(1f)) { web?.goBack() }
            DockButton("YouTube", u, Modifier.weight(1f)) { web?.loadUrl("https://m.youtube.com") }
        }
        AndroidView(modifier = Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(u * 2)), factory = { c ->
            WebView(c).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                settings.mediaPlaybackRequiresUserGesture = false
                webViewClient = WebViewClient()
                loadUrl("https://m.youtube.com")
                web = this
            }
        })
    }
}

/** Radios de México: lista editable (Nombre|URL, una por línea). */
@Composable
fun RadioScreen(u: Dp, close: () -> Unit) {
    val ctx = LocalContext.current
    var editing by remember { mutableStateOf(Cfg.radios.isBlank()) }
    var text by remember { mutableStateOf(Cfg.radios) }
    val stations = remember(Cfg.radios) { parseStations(Cfg.radios) }

    Column(Modifier.fillMaxSize().padding(u * 2), verticalArrangement = Arrangement.spacedBy(u * 1.5f)) {
        Row(horizontalArrangement = Arrangement.spacedBy(u * 1.5f)) {
            DockButton("◀ Inicio", u, Modifier.weight(1f), close)
            DockButton("Detener", u, Modifier.weight(1f)) { Radio.stop() }
            DockButton(if (editing) "Ver lista" else "Editar lista", u, Modifier.weight(1f)) { editing = !editing }
        }
        Txt(if (Radio.current != null) "${Radio.current} · ${Radio.status}" else "Radio por internet", u, 3f, Mx.Blue2, bold = true)
        if (editing) {
            Text("Una estación por línea, con este formato:  Nombre|http://link-del-stream", color = Mx.Mute, fontSize = (u.value * 2.2f).sp)
            OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth().weight(1f), minLines = 4,
                label = { Text("Mis radios") })
            DockButton("Guardar lista", u, Modifier.fillMaxWidth()) { Cfg.radios = text; Cfg.save(); editing = false }
        } else LazyVerticalGrid(columns = GridCells.Adaptive(maxOf(150.dp, u * 30)),
            horizontalArrangement = Arrangement.spacedBy(u * 1.5f), verticalArrangement = Arrangement.spacedBy(u * 1.5f)) {
            items(stations) { s ->
                val on = Radio.current == s.name
                Box(Modifier.height(maxOf(64.dp, u * 12)).clip(RoundedCornerShape(u * 2.2f)).background(Mx.Panel)
                    .border(if (on) 3.dp else 1.dp, if (on) Mx.Blue else Mx.Line, RoundedCornerShape(u * 2.2f))
                    .clickable { Radio.play(ctx, s.name, s.url) }, contentAlignment = Alignment.Center) {
                    Txt(s.name, u, 3.2f, bold = on)
                }
            }
        }
    }
}
