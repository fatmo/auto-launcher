package mx.autolauncher

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

object Mx {
    val Bg = Color(0xFF050607)
    val Panel = Color(0xFF15181D)
    val Panel2 = Color(0xFF1E2229)
    val Line = Color(0xFF2A2F38)
    val Blue = Color(0xFF2D7BFF)
    val Blue2 = Color(0xFF5AA0FF)
    val Text = Color(0xFFEEF2F7)
    val Mute = Color(0xFF8B94A3)
    // Para la tipografía tecnológica: agrega Orbitron/Rajdhani en res/font y cámbiala aquí.
    val Tech: FontFamily = FontFamily.Monospace
}

@Composable
fun LauncherTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(background = Mx.Bg, surface = Mx.Panel, primary = Mx.Blue, onSurface = Mx.Text),
        content = content
    )
}
