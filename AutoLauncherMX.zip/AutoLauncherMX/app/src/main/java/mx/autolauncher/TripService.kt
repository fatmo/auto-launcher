package mx.autolauncher

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.Looper
import android.service.notification.NotificationListenerService

/** Servicio en primer plano: mantiene el GPS activo aunque estés en Waze o Maps. */
class TripService : Service() {
    private lateinit var lm: LocationManager
    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) { Trip.onLocation(location) }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    override fun onCreate() {
        super.onCreate()
        Trip.init(this)
        Obd.start(this)
        val n = notif()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        else startForeground(1, n)
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, listener, Looper.getMainLooper())
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                val l = lm.getLastKnownLocation(p)
                if (l != null && Trip.lat == null) { Trip.lat = l.latitude; Trip.lon = l.longitude }
            }
        } catch (e: SecurityException) { stopSelf() } catch (e: Exception) {}
    }

    private fun notif(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel("trip", "Viaje", NotificationManager.IMPORTANCE_LOW))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "trip") else Notification.Builder(this)
        return b.setContentTitle("Auto Launcher MX").setContentText("Registrando viaje por GPS")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation).build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { try { lm.removeUpdates(listener) } catch (e: Exception) {}; super.onDestroy() }
}

/** Vacío a propósito: solo sirve para que Android nos deje leer la sesión de música. */
class MediaListener : NotificationListenerService()
